#!/usr/bin/env python3
"""
RemoteTouch PC Agent
====================
Captures screenshots, serves them over WebSocket, executes clicks.
Telegram bot integration for URL delivery + fallback control.

Usage:
    1. Copy .env.example → .env and fill in your tokens
    2. pip install -r requirements.txt
    3. python agent.py
"""

import asyncio
import base64
import io
import json
import logging
import os
import secrets
import sys
import time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import pyautogui
from PIL import Image
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# ─── Config ───────────────────────────────────────────────────────────
load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
NGROK_AUTH_TOKEN = os.getenv("NGROK_AUTH_TOKEN", "")
PORT = int(os.getenv("PORT", "8765"))
SCREENSHOT_QUALITY = int(os.getenv("SCREENSHOT_QUALITY", "55"))
SCREENSHOT_MAX_WIDTH = int(os.getenv("SCREENSHOT_MAX_WIDTH", "1920"))
SESSION_TOKEN = secrets.token_urlsafe(16)

# Safety
pyautogui.FAILSAFE = True  # Move mouse to corner to abort
pyautogui.PAUSE = 0.1

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger("RemoteTouch")

# ─── State ────────────────────────────────────────────────────────────
connected_clients: set[WebSocket] = set()
tunnel_url: str = ""
screen_size = pyautogui.size()
log.info(f"Screen size: {screen_size.width}x{screen_size.height}")

# ─── Screenshot Engine ────────────────────────────────────────────────
def capture_screenshot(quality: int = SCREENSHOT_QUALITY) -> tuple[str, tuple[int, int]]:
    """Capture screen, compress as JPEG, return base64 + dimensions."""
    t0 = time.perf_counter()
    shot = pyautogui.screenshot()

    # Resize for bandwidth
    if shot.width > SCREENSHOT_MAX_WIDTH:
        ratio = SCREENSHOT_MAX_WIDTH / shot.width
        new_size = (SCREENSHOT_MAX_WIDTH, int(shot.height * ratio))
        shot = shot.resize(new_size, Image.LANCZOS)

    buf = io.BytesIO()
    shot.save(buf, format="JPEG", quality=quality, optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")

    elapsed = (time.perf_counter() - t0) * 1000
    size_kb = len(buf.getvalue()) / 1024
    log.info(f"Screenshot: {shot.size[0]}x{shot.size[1]}, {size_kb:.0f}KB, {elapsed:.0f}ms")

    return b64, shot.size


def perform_click(x_ratio: float, y_ratio: float, button: str = "left"):
    """Click at normalized coordinates (0-1 range)."""
    sw, sh = pyautogui.size()
    x = int(x_ratio * sw)
    y = int(y_ratio * sh)
    x = max(0, min(x, sw - 1))
    y = max(0, min(y, sh - 1))

    if button == "right":
        pyautogui.rightClick(x, y)
    elif button == "double":
        pyautogui.doubleClick(x, y)
    else:
        pyautogui.click(x, y)

    log.info(f"Click: ({x}, {y}) [{button}] (ratio: {x_ratio:.3f}, {y_ratio:.3f})")


def perform_scroll(x_ratio: float, y_ratio: float, delta: int):
    """Scroll at normalized coordinates."""
    sw, sh = pyautogui.size()
    x = int(x_ratio * sw)
    y = int(y_ratio * sh)
    pyautogui.moveTo(x, y)
    pyautogui.scroll(delta)
    log.info(f"Scroll: ({x}, {y}) delta={delta}")


def perform_keypress(keys: str):
    """Send keyboard input. Supports hotkeys like 'ctrl+c'."""
    if "+" in keys:
        pyautogui.hotkey(*keys.split("+"))
    else:
        pyautogui.press(keys)
    log.info(f"Keypress: {keys}")


def type_text(text: str):
    """Type text string."""
    pyautogui.typewrite(text, interval=0.02)
    log.info(f"Type: '{text[:50]}...'")


# ─── FastAPI App ──────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: create tunnel, notify via Telegram."""
    global tunnel_url

    # Start ngrok tunnel
    if NGROK_AUTH_TOKEN:
        try:
            from pyngrok import ngrok, conf
            conf.get_default().auth_token = NGROK_AUTH_TOKEN
            tunnel = ngrok.connect(PORT, "http")
            tunnel_url = tunnel.public_url.replace("http://", "https://")
            log.info(f"Tunnel: {tunnel_url}")
        except Exception as e:
            log.error(f"Ngrok failed: {e}")
            tunnel_url = f"http://localhost:{PORT}"
    else:
        tunnel_url = f"http://localhost:{PORT}"
        log.warning("No NGROK_AUTH_TOKEN — running on localhost only")

    # Build app URL with auth token
    app_url = f"{tunnel_url}/app?token={SESSION_TOKEN}"
    ws_url = f"{tunnel_url.replace('https://', 'wss://').replace('http://', 'ws://')}/ws?token={SESSION_TOKEN}"

    log.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    log.info(f"  RemoteTouch Agent Started")
    log.info(f"  App URL : {app_url}")
    log.info(f"  WS URL  : {ws_url}")
    log.info(f"  Token   : {SESSION_TOKEN}")
    log.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    # Send URL via Telegram
    if TELEGRAM_TOKEN and TELEGRAM_CHAT_ID:
        await send_telegram_message(
            f"🖥 *RemoteTouch Active*\n\n"
            f"📱 [Open Remote Control]({app_url})\n\n"
            f"Token: `{SESSION_TOKEN}`\n"
            f"Screen: {screen_size.width}x{screen_size.height}"
        )

    yield

    # Shutdown
    if NGROK_AUTH_TOKEN:
        try:
            from pyngrok import ngrok
            ngrok.kill()
        except:
            pass
    log.info("Agent stopped.")


app = FastAPI(lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Auth Middleware ──────────────────────────────────────────────────
def verify_token(token: str):
    if token != SESSION_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid token")


# ─── HTTP Endpoints ──────────────────────────────────────────────────
@app.get("/app")
async def serve_app(token: str = Query(...)):
    """Serve the PWA HTML."""
    verify_token(token)
    pwa_path = Path(__file__).parent.parent / "phone-app" / "index.html"
    if pwa_path.exists():
        html = pwa_path.read_text()
        # Inject WebSocket URL and token
        ws_base = tunnel_url.replace("https://", "wss://").replace("http://", "ws://")
        html = html.replace("{{WS_URL}}", f"{ws_base}/ws?token={token}")
        html = html.replace("{{TOKEN}}", token)
        return HTMLResponse(html)
    return HTMLResponse("<h1>PWA not found. Check phone-app/index.html</h1>", status_code=404)


@app.get("/health")
async def health():
    return {"status": "ok", "screen": f"{screen_size.width}x{screen_size.height}"}


@app.get("/screenshot")
async def get_screenshot(token: str = Query(...)):
    """REST endpoint for single screenshot (Telegram fallback)."""
    verify_token(token)
    b64, size = capture_screenshot(quality=40)
    return JSONResponse({"image": b64, "width": size[0], "height": size[1]})


# ─── WebSocket ────────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, token: str = Query("")):
    if token != SESSION_TOKEN:
        await ws.close(code=4003, reason="Unauthorized")
        return

    await ws.accept()
    connected_clients.add(ws)
    client_ip = ws.client.host if ws.client else "unknown"
    log.info(f"Client connected: {client_ip} (total: {len(connected_clients)})")

    try:
        # Send initial screenshot
        b64, size = capture_screenshot()
        await ws.send_json({
            "type": "screenshot",
            "image": b64,
            "width": size[0],
            "height": size[1],
            "screen_width": screen_size.width,
            "screen_height": screen_size.height,
            "timestamp": time.time()
        })

        while True:
            raw = await ws.receive_text()
            data = json.loads(raw)
            msg_type = data.get("type", "")

            if msg_type == "click":
                perform_click(
                    data["x"], data["y"],
                    data.get("button", "left")
                )
                # Wait for UI to update
                delay = data.get("delay", 0.3)
                await asyncio.sleep(delay)
                b64, size = capture_screenshot()
                await ws.send_json({
                    "type": "screenshot",
                    "image": b64,
                    "width": size[0],
                    "height": size[1],
                    "timestamp": time.time()
                })

            elif msg_type == "scroll":
                perform_scroll(data["x"], data["y"], data.get("delta", -3))
                await asyncio.sleep(0.2)
                b64, size = capture_screenshot()
                await ws.send_json({
                    "type": "screenshot",
                    "image": b64,
                    "width": size[0],
                    "height": size[1],
                    "timestamp": time.time()
                })

            elif msg_type == "key":
                perform_keypress(data["keys"])
                await asyncio.sleep(0.2)
                b64, size = capture_screenshot()
                await ws.send_json({
                    "type": "screenshot",
                    "image": b64,
                    "width": size[0],
                    "height": size[1],
                    "timestamp": time.time()
                })

            elif msg_type == "type":
                type_text(data["text"])
                await asyncio.sleep(0.2)
                b64, size = capture_screenshot()
                await ws.send_json({
                    "type": "screenshot",
                    "image": b64,
                    "width": size[0],
                    "height": size[1],
                    "timestamp": time.time()
                })

            elif msg_type == "refresh":
                quality = data.get("quality", SCREENSHOT_QUALITY)
                b64, size = capture_screenshot(quality=quality)
                await ws.send_json({
                    "type": "screenshot",
                    "image": b64,
                    "width": size[0],
                    "height": size[1],
                    "timestamp": time.time()
                })

            elif msg_type == "ping":
                await ws.send_json({"type": "pong", "timestamp": time.time()})

    except WebSocketDisconnect:
        log.info(f"Client disconnected: {client_ip}")
    except Exception as e:
        log.error(f"WebSocket error: {e}")
    finally:
        connected_clients.discard(ws)


# ─── Telegram Bot ─────────────────────────────────────────────────────
async def send_telegram_message(text: str):
    """Send a message via Telegram Bot API."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        import httpx
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
                json={
                    "chat_id": TELEGRAM_CHAT_ID,
                    "text": text,
                    "parse_mode": "Markdown",
                    "disable_web_page_preview": False
                }
            )
    except Exception as e:
        log.error(f"Telegram send failed: {e}")


async def send_telegram_photo(image_bytes: bytes, caption: str = ""):
    """Send a screenshot via Telegram."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        import httpx
        async with httpx.AsyncClient() as client:
            await client.post(
                f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendPhoto",
                data={"chat_id": TELEGRAM_CHAT_ID, "caption": caption},
                files={"photo": ("screenshot.jpg", image_bytes, "image/jpeg")}
            )
    except Exception as e:
        log.error(f"Telegram photo failed: {e}")


# ─── Telegram Polling (background task) ──────────────────────────────
async def telegram_polling():
    """Poll Telegram for commands as fallback control."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return

    import httpx
    offset = 0
    log.info("Telegram polling started")

    async with httpx.AsyncClient(timeout=35.0) as client:
        while True:
            try:
                resp = await client.get(
                    f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/getUpdates",
                    params={"offset": offset, "timeout": 30}
                )
                updates = resp.json().get("result", [])

                for update in updates:
                    offset = update["update_id"] + 1
                    msg = update.get("message", {})
                    text = msg.get("text", "").strip()
                    chat_id = str(msg.get("chat", {}).get("id", ""))

                    if chat_id != str(TELEGRAM_CHAT_ID):
                        continue

                    if text == "/ss" or text == "/screenshot":
                        shot = pyautogui.screenshot()
                        buf = io.BytesIO()
                        shot.save(buf, format="JPEG", quality=50)
                        await send_telegram_photo(
                            buf.getvalue(),
                            f"📸 {datetime.now().strftime('%H:%M:%S')}"
                        )

                    elif text.startswith("/click"):
                        parts = text.split()
                        if len(parts) == 3:
                            try:
                                x, y = int(parts[1]), int(parts[2])
                                pyautogui.click(x, y)
                                await asyncio.sleep(0.5)
                                shot = pyautogui.screenshot()
                                buf = io.BytesIO()
                                shot.save(buf, format="JPEG", quality=50)
                                await send_telegram_photo(
                                    buf.getvalue(),
                                    f"✅ Clicked ({x}, {y})"
                                )
                            except ValueError:
                                await send_telegram_message("❌ Usage: /click x y")

                    elif text.startswith("/key"):
                        keys = text[5:].strip()
                        if keys:
                            perform_keypress(keys)
                            await send_telegram_message(f"⌨️ Sent: {keys}")

                    elif text == "/url":
                        app_url = f"{tunnel_url}/app?token={SESSION_TOKEN}"
                        await send_telegram_message(f"📱 [Open Remote]({app_url})")

                    elif text == "/help":
                        await send_telegram_message(
                            "🖥 *RemoteTouch Commands*\n\n"
                            "/ss — Screenshot\n"
                            "/click x y — Click at pixel coords\n"
                            "/key keys — Send keypress (e.g. /key ctrl+c)\n"
                            "/url — Get app URL\n"
                            "/help — This message"
                        )

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"Telegram poll error: {e}")
                await asyncio.sleep(5)


# ─── Main ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Start Telegram polling in background
    import threading

    if TELEGRAM_TOKEN and TELEGRAM_CHAT_ID:
        def run_telegram():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(telegram_polling())

        t = threading.Thread(target=run_telegram, daemon=True)
        t.start()

    log.info(f"Starting server on port {PORT}...")
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")
