# RemoteTouch — Telefondan PC Uzaktan Kontrol

Telefonunuzdan PC ekranını görüntüleyin ve dokunarak kontrol edin.  
Altyapı: WebSocket (gerçek zamanlı) + Telegram Bot (URL iletimi & fallback kontrol).

## Mimari

```
┌─────────────┐      ngrok tunnel      ┌───────────────┐
│   PC Agent   │◄──────────────────────►│   Phone PWA   │
│  (Python)    │     WebSocket (WSS)    │  (Safari/iOS) │
│              │                        │               │
│  pyautogui   │  ┌─────────────────┐   │  Touch events │
│  FastAPI     │  │  Telegram Bot   │   │  → coordinates│
│  screenshot  │  │  (URL + /ss     │   │  → PC click   │
│  + click     │  │   /click /key)  │   │  ← screenshot │
└─────────────┘  └─────────────────┘   └───────────────┘
```

## Kurulum

### 1. Gereksinimler

- Python 3.10+
- Ngrok hesabı (ücretsiz): https://ngrok.com
- Telegram Bot Token: @BotFather → /newbot

### 2. PC Agent Kurulumu

```bash
cd pc-agent
pip install -r requirements.txt

# .env dosyasını oluştur
cp .env.example .env
# .env'i düzenle: TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, NGROK_AUTH_TOKEN
```

#### Telegram Chat ID Bulma

1. Bot'unuza Telegram'dan bir mesaj gönderin
2. Tarayıcıda açın:  
   `https://api.telegram.org/bot<TOKEN>/getUpdates`
3. `"chat":{"id": 123456}` → bu sizin CHAT_ID'niz

### 3. Çalıştırma

```bash
cd pc-agent
python agent.py
```

Agent başladığında:
- Ngrok tunnel oluşturur
- Telegram'a uygulama URL'sini gönderir (tokenli link)
- WebSocket bağlantısını bekler

### 4. Telefonda Kullanım

1. Telegram'dan gelen linke tıklayın
2. Safari'de açılır → PWA yüklenir
3. **Telefonu yatay çevirin** (landscape)
4. Dokunun → PC'de tıklar → yeni screenshot gelir

#### iOS'ta "App" Olarak Kaydetme

1. Safari'de linki açın
2. Paylaş butonu (□↑) → "Ana Ekrana Ekle"
3. Artık native app gibi çalışır (tam ekran, Safari UI yok)

## Kontroller

| Hareket | İşlem |
|---------|-------|
| Tek dokunma | Sol tıklama |
| Çift dokunma | Çift tıklama |
| Uzun basma (0.5s) | Sağ tıklama |
| ☰ butonu + kaydırma | Scroll |
| ⌨ butonu | Klavye paneli |
| ↻ butonu | Ekranı yenile |

### Telegram Fallback Komutları

| Komut | İşlem |
|-------|-------|
| `/ss` | Screenshot al |
| `/click x y` | Piksel koordinatına tıkla |
| `/key ctrl+c` | Tuş kombinasyonu gönder |
| `/url` | Uygulama linkini tekrar al |
| `/help` | Yardım |

## Ayarlar (.env)

| Değişken | Varsayılan | Açıklama |
|----------|-----------|----------|
| `PORT` | 8765 | Yerel server portu |
| `SCREENSHOT_QUALITY` | 55 | JPEG kalitesi (20-95). Düşük = hızlı, yüksek = net |
| `SCREENSHOT_MAX_WIDTH` | 1920 | Max genişlik (bandwidth optimizasyonu) |

## Güvenlik

- Her oturum benzersiz bir token üretir (URL'de gömülü)
- Token olmadan WebSocket bağlantısı reddedilir
- Ngrok tunnel her çalıştırmada farklı URL verir
- `pyautogui.FAILSAFE = True` → mouse'u ekranın köşesine sürükleyerek durdurabilirsiniz

## Sorun Giderme

**Bağlantı kurulamıyor:**
- PC'de firewall port 8765'i engelliyor olabilir
- Ngrok auth token'ı kontrol edin
- `.env` dosyasının doğru yolda olduğundan emin olun

**Ekran görüntüsü gelmiyor:**
- macOS: System Preferences → Privacy → Screen Recording → Terminal'e izin verin
- Linux: `sudo apt install python3-xlib scrot` gerekebilir

**Yüksek gecikme:**
- `SCREENSHOT_QUALITY` değerini 35-40'a düşürün
- `SCREENSHOT_MAX_WIDTH` değerini 1280'e düşürün
- Daha yakın bir ngrok bölgesi seçin

## Geliştirme Notları

- PWA'daki `{{WS_URL}}` ve `{{TOKEN}}` placeholder'ları agent tarafından dinamik olarak doldurulur
- Standalone test için: PWA'daki placeholder'ları manuel olarak değiştirip doğrudan tarayıcıda açabilirsiniz
- Agent `0.0.0.0` üzerinde dinler — aynı ağdaysa ngrok olmadan `http://<PC_IP>:8765/app?token=XXX` ile de erişebilirsiniz
